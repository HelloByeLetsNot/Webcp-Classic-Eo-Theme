<?php

class LoginRate_none
{
	public function __construct()
	{
	}

	public function get($key)
	{
		return "";
	}

	public function set($key, $value)
	{
	}
}
