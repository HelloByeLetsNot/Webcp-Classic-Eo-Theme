
</div>

<div id="footer">
<span id="copyright">Template &copy; Copyright 2009 <a href="http://tehsausage.com/">Julian Smythe</a></span>
<span id="about">Powered by <a href="http://eoserv.net/">EOSERV</a> WebCP</span>
</div>
