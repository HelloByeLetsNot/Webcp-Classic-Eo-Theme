
<span class="showing">Showing top <?php echo htmlspecialchars(isset($limit)?$limit:'',ENT_QUOTES,'UTF-8') ?> characters</span>

<table id="players">
	<thead>
		<tr>
			<th>Name
			<th>Title
			<th>Gender
			<th>Level
			<th>Exp
	<tbody>
<?php if (isset($characters)){ if (!is_array($characters)) $characters = array($characters); foreach($characters as $eachcount => $char){ ?>
		<tr>
			<td><?php if(isset($GM) && $GM){ ?><a href="./character<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>?name=<?php echo htmlspecialchars(urlencode(isset($char['name'])?$char['name']:''),ENT_QUOTES,'UTF-8') ?>"><?php } ?><?php echo htmlspecialchars(isset($char['name'])?$char['name']:'',ENT_QUOTES,'UTF-8') ?><?php if(isset($GM) && $GM){ ?></a><?php } ?>

			<td><?php echo htmlspecialchars(isset($char['title'])?$char['title']:'',ENT_QUOTES,'UTF-8') ?>

			<td><?php echo htmlspecialchars(isset($char['gender'])?$char['gender']:'',ENT_QUOTES,'UTF-8') ?>

			<td><?php echo htmlspecialchars(isset($char['level'])?$char['level']:'',ENT_QUOTES,'UTF-8') ?>

			<td><?php echo htmlspecialchars(isset($char['exp'])?$char['exp']:'',ENT_QUOTES,'UTF-8') ?>

<?php }} ?>
</table>

<div class="showing">Showing top <?php echo htmlspecialchars(isset($limit)?$limit:'',ENT_QUOTES,'UTF-8') ?> characters</div>
