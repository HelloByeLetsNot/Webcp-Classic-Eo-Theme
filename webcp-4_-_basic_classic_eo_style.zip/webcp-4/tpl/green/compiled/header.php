<!DOCTYPE html>
<title><?php echo htmlspecialchars(isset($sitename)?$sitename:'',ENT_QUOTES,'UTF-8') ?> :: EOSERV Control Panel :: <?php echo htmlspecialchars(isset($pagetitle)?$pagetitle:'',ENT_QUOTES,'UTF-8') ?></title>
<link rel="stylesheet" href="./tpl/green/style.css">

<div id="header">
<span id="subtitle">

</span>
<h2></h2>
</div>

<ul class="nav">
	<li><a href="./index<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>">Home</a>
	<li><a href="./players<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>">Top&nbsp;Players</a>
	<li><a href="./guilds<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>">Top&nbsp;Guilds</a>
	<li><a href="./staff<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>">Staff</a>
	<li><a href="./online<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>">Online List</a>
</ul>

<?php if(isset($logged) && $logged){ ?>
<ul class="nav playernav">
	<li><span><?php echo htmlspecialchars(isset($username)?$username:'',ENT_QUOTES,'UTF-8') ?></span>
	<li><a href="./characters<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>">My&nbsp;Characters&nbsp;(<?php echo htmlspecialchars(isset($numchars)?$numchars:'',ENT_QUOTES,'UTF-8') ?>)</a>
	<li><a href="./logout<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>?csrf=<?php echo htmlspecialchars(urlencode(isset($csrf)?$csrf:''),ENT_QUOTES,'UTF-8') ?>">Logout</a>
</ul>
<?php } ?>

<?php if (isset($chardata_guilds)){ if (!is_array($chardata_guilds)) $chardata_guilds = array($chardata_guilds); foreach($chardata_guilds as $tag => $guild){ ?>
<ul class="nav guildnav">
	<li><span>Guild: <a href="./guild<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>?tag=<?php echo htmlspecialchars(urlencode(isset($tag)?$tag:''),ENT_QUOTES,'UTF-8') ?>"><?php echo htmlspecialchars(isset($tag)?$tag:'',ENT_QUOTES,'UTF-8') ?></a></span>
	<li><a href="./guildmembers<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>?tag=<?php echo htmlspecialchars(urlencode(isset($tag)?$tag:''),ENT_QUOTES,'UTF-8') ?>">Member&nbsp;List</a>
</ul>
<?php }} ?>

<?php if(isset($GUIDE) && $GUIDE){ ?>
<ul class="nav guidenav">
	<li><span>Light Guide Tools</span>
	<li><a href="./reports<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>">Reports</a>
</ul>
<?php } ?>

<?php if(isset($GUARDIAN) && $GUARDIAN){ ?>
<ul class="nav guardiannav">
	<li><span>Guardian Tools</span>
	<li><a href="./bans<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>">Ban&nbsp;Control</a>
</ul>
<?php } ?>

<?php if(isset($GM) && $GM){ ?>
<ul class="nav gmnav">
	<li><span>GM Tools</span>
	<li><a href="./allaccounts<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>">All&nbsp;Accounts</a>
	<li><a href="./allcharacters<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>">All&nbsp;Characters</a>
	<li><a href="./allguilds<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>">All&nbsp;Guilds</a>
	<li><a href="./search<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>">Search</a>
</ul>
<?php } ?>

<div id="article">

<?php if(isset($message) && $message){ ?>
<span class="message"><?php echo (isset($message)?$message:'') ?></span>

<?php } ?>
<?php if(isset($error) && $error){ ?>
<span class="error"><?php echo (isset($error)?$error:'') ?></span>

<?php } ?>
<div class="aside" id="status">
<h3>Server Status</h3>
<?php echo (isset($statusstr)?$statusstr:'') ?><br>
<?php if(isset($online) && $online){ ?>
<small>Online: <a href="./online<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>"><b><?php echo htmlspecialchars(isset($onlinecharacters)?$onlinecharacters:'',ENT_QUOTES,'UTF-8') ?></b>/<b><?php echo htmlspecialchars(isset($maxplayers)?$maxplayers:'',ENT_QUOTES,'UTF-8') ?></b></a></small>
<?php } ?>
</div>

<?php if(!isset($logged) || !$logged){ ?>

<div class="aside">
<h3>Login</h3>
<form action="<?php if(isset($loggingout) && $loggingout){ ?>./<?php } ?>" method="POST">
<input type="hidden" name="action" value="login">
<label for="username">Username</label>
<input type="text" name="username" id="username">
<label for="password">Password</label>
<input type="password" name="password" id="password">
<?php if(isset($login_need_captcha) && $login_need_captcha){ ?>
<label for="captcha">CAPTCHA</label>
<p>You have entered too many invalid passwords. Please enter the letters shown in the image.</p>
<img src="./captcha<?php echo htmlspecialchars(isset($php)?$php:'',ENT_QUOTES,'UTF-8') ?>">
<input type="text" name="captcha" id="captcha">
<?php } ?>
<input type="submit" id="submit" value="Login">
</form>
</div>
<?php } ?>
