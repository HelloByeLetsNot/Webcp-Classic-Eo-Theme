<ul><hl>

	
	<br>
	<span class="titlebar">News Headlines</span>
<br>
<span class="newsbar">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1/12/23&nbsp;&nbsp;&nbsp;&nbsp;First Template Edit</span>
<span class="newsbody">Here is my first edit of the template its what it is.</span>

<span class="newsbar">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Server Stats&nbsp;&nbsp;&nbsp;&nbsp;</span>
<span class="newsbody">	<li>Server Name: <b><?php echo htmlspecialchars(isset($sitename)?$sitename:'',ENT_QUOTES,'UTF-8') ?></b>
	<li>Accounts: <b><?php echo htmlspecialchars(isset($accounts)?$accounts:'',ENT_QUOTES,'UTF-8') ?></b>
	<li>Characters: <b><?php echo htmlspecialchars(isset($characters)?$characters:'',ENT_QUOTES,'UTF-8') ?></b> (<b><?php echo htmlspecialchars(isset($staffcharacters)?$staffcharacters:'',ENT_QUOTES,'UTF-8') ?></b> staff)
	<li>Guilds: <b><?php echo htmlspecialchars(isset($guilds)?$guilds:'',ENT_QUOTES,'UTF-8') ?></b>
<?php if(isset($bank) && $bank){ ?>
	<li>Our banks store a total of <b><?php echo htmlspecialchars(isset($bank)?$bank:'',ENT_QUOTES,'UTF-8') ?></b> gold.
		<br>
		<br><?php } ?> </span>
</ul>
